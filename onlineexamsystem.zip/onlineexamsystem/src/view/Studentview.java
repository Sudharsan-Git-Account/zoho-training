package view;

import controller.*;
import java.util.List;
import java.util.Scanner;
import modellayer.*;
import utils.*;

public class Studentview {

    private final Scanner sc = Inpututil.getScanner();
    private final ExamController examController = ExamController.getInstance();
    private final ResultController resultController = ResultController.getInstance();
    private final UserController userController = UserController.getInstance();

    public void takeExam(User student) {
        viewAvailableExams();
        int examId = Inpututil.getIntInput("Enter Exam No to start: ");

        List<Question> questions = examController.getQuestionsByExamId(examId);

        if (questions == null || questions.isEmpty()) {
            System.out.println("No questions available for this exam.");
            return;
        }

        System.out.println("\n--- Starting Exam ---");
        
        int questionNo = 1;
        for (Question q : questions) {
            System.out.println("\nQuestion " + questionNo + ": " + q.getText());

            List<Option> options = examController.getOptionsByQuestionId(q.getId());
            if (options.isEmpty()) {
                System.out.println("No options available for this question!");
                questionNo++;
                continue;
            }

            int optionNo = 1;
            for (Option opt : options) {
                System.out.println("  "+optionNo + ". " + opt.getText());
                optionNo++;
            }
            int choice = Inpututil.getIntInput("Enter your option (1-" + options.size() + "): ", 1, options.size());
            int selectedOption = options.get(choice - 1).getId();
            examController.saveAnswer(student.getId(), examId, q.getId(), selectedOption);
            questionNo++;
        }

        examController.evaluateAndSaveResult(student.getId(), examId);
    }


    public void viewResult(User student) {
    System.out.println("\n--- My Results ---");
    List<Result> allResults = resultController.showResult(student.getId());
    if (allResults.isEmpty()) {
        System.out.println("No Results found.");
        return;
    }
    System.out.println("\n--- Exam Summary ---");
    for (Result r : allResults) {
        r.setPassOrFail(r.getScore(), r.getTotalMarks());
        System.out.println("Exam ID " + r.getExamId() + " -> Score: " 
                + r.getScore() + "/"+r.getTotalMarks()+ " (" + (r.getPassOrFail() ? "Pass" : "Fail") + ")");
    }

    int examId = Inpututil.getIntInput("\nEnter Exam ID to view detailed report: ");

    Result selected = allResults.stream()
            .filter(r -> r.getExamId() == examId)
            .findFirst()
            .orElse(null);

    if (selected == null) {
        System.out.println("Invalid Exam ID!");
        return;
    }
    List<Answer> answers;
    try {
        answers = examController.getAnswersByUserAndExam(student.getId(), examId);
    } catch (Exception e) {
        System.out.println("Error loading answer details: " + e.getMessage());
        return;
    }

    List<Question> questions = examController.getQuestionsByExamId(examId);

    System.out.println("\n==============================");
    System.out.println("     DETAILED EXAM REPORT     ");
    System.out.println("==============================");
    System.out.println("Exam ID: " + examId);
    System.out.println("Score  : " + selected.getScore() + "%");
    System.out.println("Correct: " + selected.getCorrectAnswers() + "/" + selected.getTotalQuestions());
    System.out.println("==============================\n");

    int qNo = 1;

    for (Question q : questions) {
        System.out.println("Q" + qNo + ": " + q.getText());

        Answer userAns = answers.stream()
                .filter(a -> a.getQuestionId() == q.getId())
                .findFirst()
                .orElse(null);

        if (userAns == null) {
            System.out.println("Your Answer: (Not Attempted)");
            System.out.println("Correct Answer: " + examController.getCorrectOptionText(q.getId()));
            System.out.println("Result: ✘ Wrong\n");
            qNo++;
            continue;
        }

        String userAnswer = examController.getOptionTextById(userAns.getSelectedOptionId());
        String correctAnswer = examController.getCorrectOptionText(q.getId());

        boolean isCorrect = userAns.getSelectedOptionId() ==
                examController.getCorrectOptionId(q.getId());

        System.out.println("Your Answer   : " + userAnswer);
        System.out.println("Correct Answer: " + correctAnswer);
        System.out.println("Result        : " + (isCorrect ? "✔ Correct" : "✘ Wrong"));
        System.out.println();
        qNo++;
    }
}


    public void viewAvailableExams() {
        System.out.println("\n--- Available Exams ---");
        List<Exam> exams = examController.getAllExams();
        if (exams.isEmpty()) System.out.println("No exams available.");
        else{
            int examCount = 1;
            for(Exam exam: exams){
                System.out.println(examCount+". "+exam.getTitle());
                examCount++;
            }
        }
        System.out.println();
    }

    public void searchExam() {
        String keyword = Inpututil.getNonEmptyString("Enter exam keyword: ");
        List<Exam> results = examController.searchExamByTitle(keyword);
        if (results.isEmpty()) System.out.println("No exams found.");
        else results.forEach(e -> System.out.println("- " + e.getTitle()));
    }

    public void viewProfile(User student) {
        System.out.println("\n--- My Profile ---");
        System.out.println("Full Name: " + student.getFullName());
        System.out.println("Username : " + student.getUsername());
        System.out.println("Role     : " + student.getRole());
    }

    public void changePassword(User student) {
        String oldPass = Inpututil.getNonEmptyString("Enter current password: ");
        String newPass = Inpututil.getNonEmptyString("Enter new password: ");
        userController.changePassword(student, oldPass, newPass);

    }
}
