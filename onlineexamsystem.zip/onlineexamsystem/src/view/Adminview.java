package view;

import controller.*;
import java.util.List;
import java.util.Scanner;
import modellayer.*;
import utils.Inpututil;

public class Adminview {

    private final Scanner sc = Inpututil.getScanner();
    private final ExamController examController = ExamController.getInstance();
    private final UserController userController = UserController.getInstance();
    private final ResultController resultController = ResultController.getInstance();

    public void createExam() {
        System.out.println("\n--- Create Exam ---");
        int userId = Inpututil.getIntInput("Enter Your Id: ");
        String title = Inpututil.getNonEmptyString("Enter exam title: ");
        String description = Inpututil.getNonEmptyString("Enter exam description: ");
        int duration = Inpututil.getIntInput("Enter duration (minutes): ", 1, 300);
        examController.createExam(title, description, duration,userId);
    }

    public void viewExams() {
        System.out.println("\n--- All Exams ---");
        List<Exam> exams = examController.getAllExams();
        if (exams.isEmpty()) {
            System.out.println("No exams found.");
        } else {
            int examNo = 1;
            for (Exam e : exams) {
                System.out.println(examNo+". " + e.getTitle() + " (" + e.getDurationMinutes() + " mins)");
                examNo++;
            }
        }
    }

    public void updateExam() {
        viewExams();

        int id = Inpututil.readInt("Enter the Exam ID to update: ");
        String title = Inpututil.getNonEmptyString("Enter new Exam Title: ");
        String description = Inpututil.getNonEmptyString("Enter new Exam Description: ");
        int duration = Inpututil.readInt("Enter new Exam Duration (in minutes): ");

        examController.updateExam(id, title, description, duration);
    }


    public void deleteExam() {
        viewExams();
        int id = Inpututil.readInt("Enter the Exam ID to update: ");
        String title = Inpututil.getNonEmptyString("Enter the title of the exam to delete: ");
        System.out.print("Are you sure (y/n)? ");
        String confirm = sc.nextLine().trim();
        if (confirm.equalsIgnoreCase("y")) {
            examController.deleteExam(id);
        }

    }

    public void addQuestionToExam() {
        System.out.println("\n--- Add Question ---");

        String examTitle = Inpututil.getNonEmptyString("Enter exam title: ");

        int examId = -1;
        try {
            List<Exam> exams = examController.getAllExams();
            for (Exam e : exams) {
                if (e.getTitle().equalsIgnoreCase(examTitle)) {
                    examId = e.getId();
                    break;
                }
            }
        } catch (Exception ex) {
            System.out.println(" Error fetching exams: " + ex.getMessage());
            return;
        }
        if (examId == -1) {
            System.out.println(" Exam not found with title: " + examTitle);
            return;
        }

        String questionText = Inpututil.getNonEmptyString("Enter question text: ");
        int marks = Inpututil.getIntInput("Marks for this question: ", 1, 100);

        String optionA = Inpututil.getNonEmptyString("Option A: ");
        String optionB = Inpututil.getNonEmptyString("Option B: ");
        String optionC = Inpututil.getNonEmptyString("Option C: ");
        String optionD = Inpututil.getNonEmptyString("Option D: ");

        String correctOption = Inpututil.getNonEmptyString("Correct Option (A/B/C/D): ").trim().toUpperCase();
        if (!correctOption.matches("[ABCD]")) {
            System.err.println("Invalid correct option. Use A, B, C or D.");
            return;
        }

        try {
        Question created = QuestionController.getInstance().addQuestion(examId, questionText, marks);
            if (created == null || created.getId() == 0) {
                System.err.println("Failed to create question.");
                return;
            }
            int qId = created.getId();

            OptionController oc = OptionController.getInstance();
            Option a = oc.addOption(qId, optionA, correctOption.equals("A"));
            Option b = oc.addOption(qId, optionB, correctOption.equals("B"));
            Option c = oc.addOption(qId, optionC, correctOption.equals("C"));
            Option d = oc.addOption(qId, optionD, correctOption.equals("D"));

            if (created != null) {
                int correctOptionId = 0;
                if (correctOption.equals("A") && a != null) correctOptionId = a.getId();
                if (correctOption.equals("B") && b != null) correctOptionId = b.getId();
                if (correctOption.equals("C") && c != null) correctOptionId = c.getId();
                if (correctOption.equals("D") && d != null) correctOptionId = d.getId();

                if (correctOptionId != 0) {
                    created.setOptionId(correctOptionId);
                    QuestionController.getInstance().updateQuestion(created);
                }
            }

            System.out.println(" Question added successfully to exam: " + examTitle);
        } catch (Exception e) {
            System.err.println(" Failed to add question: " + e.getMessage());
        }
    }


    public void viewAllStudents() {
        System.out.println("\n--- Registered Students ---");
        List<User> students = userController.showAllUsers();
        if (students.isEmpty()) {
            System.out.println("No students registered.");
        } else {
            for (User s : students) {
                if(s.getId() != 1){
                System.out.println("- " + s.getFullName() + " (" + s.getUsername() + ")");
                }
            }
        }
    }

    public void viewAllResults() {
        System.out.println("\n--- All Results ---");
        resultController.showAllResults().forEach(r ->
            System.out.println(r.getId() + " - Rollno: " + (r.getUserId()-1) +" ->"+r.getExamTitle()+ ": " + r.getScore() + " out of " + r.getTotalMarks() + " (" + (r.getPassOrFail() ? "Pass" : "Fail") + ") ")
        );
    }

    public void searchExamByTitle() {
        String keyword = Inpututil.getNonEmptyString("Enter exam title keyword: ");
        List<Exam> results = examController.searchExamByTitle(keyword);
        if (results.isEmpty()) {
            System.out.println("No exams match your search.");
        } else {
            results.forEach(e -> System.out.println("- " + e.getTitle()));
        }
    }
}
