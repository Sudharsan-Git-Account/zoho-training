package service.serviceinterface;

import modellayer.Result;
import java.util.*;

public interface IResultService {
    Result evaluateExam(int userId, int examId) throws Exception;
    Optional<Result> getResultByUserAndExam(int userId, int examId) throws Exception;
}
