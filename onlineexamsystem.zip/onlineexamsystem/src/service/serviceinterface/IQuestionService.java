package service.serviceinterface;

import modellayer.Question;
import java.util.*;

public interface IQuestionService {
    Question addQuestion(Question question) throws Exception;
    boolean updateQuestion(Question question) throws Exception;
    boolean deleteQuestion(int id) throws Exception;
    List<Question> getQuestionsByExam(int examId) throws Exception;
}
