package service.serviceinterface;

import modellayer.Exam;
import java.util.*;

public interface IExamService {
    Optional<Exam> getExamById(int id) throws Exception;
    List<Exam> getAllExams() throws Exception;
    Exam createExam(Exam exam) throws Exception;
    boolean removeExam(int id) throws Exception;
    boolean updateExam(Exam exam) throws Exception;
    
}
