package service.serviceinterface;

import modellayer.Option;
import java.util.*;

public interface IOptionService {
    Option addOption(Option option) throws Exception;
    List<Option> getOptionsByQuestion(int questionId) throws Exception;
    boolean removeOptionsByQuestion(int questionId) throws Exception;
}
