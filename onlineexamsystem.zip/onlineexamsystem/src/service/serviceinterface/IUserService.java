package service.serviceinterface;

import modellayer.User;
import java.util.*;

public interface IUserService {
    User registerUser(User user) throws Exception;
    Optional<User> login(String username, String password) throws Exception;
    List<User> getAllUsers() throws Exception;
    boolean removeUser(int id) throws Exception;

}
