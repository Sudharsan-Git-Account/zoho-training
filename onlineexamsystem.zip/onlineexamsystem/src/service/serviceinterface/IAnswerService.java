package service.serviceinterface;

import modellayer.Answer;
import java.util.*;

public interface IAnswerService {
    Answer saveAnswer(Answer answer) throws Exception;
    List<Answer> getAnswersByResultId(int userId,int examId) throws Exception;
    boolean clearAnswers(int userId,int examId) throws Exception;
}
