package service.serviceimpliments;

import dao.daoimplimentations.UserDAO;
import modellayer.User;
import service.serviceinterface.IUserService;

import java.util.*;

public class UserService implements IUserService {

    private static volatile UserService instance;
    private final UserDAO userDao = UserDAO.getInstance();

    public static UserService getInstance() {
        if (instance == null) {
            synchronized (UserService.class) {
                if (instance == null) instance = new UserService();
            }
        }
        return instance;
    }

    @Override
    public User registerUser(User user) throws Exception {
        Optional<User> existing = userDao.findByUsername(user.getUsername());
        if (existing.isPresent()) {
            throw new Exception("Username already exists: " + user.getUsername());
        }
        return userDao.save(user);
    }

    @Override
    public Optional<User> login(String username, String password) throws Exception {
        Optional<User> userOpt = userDao.findByUsername(username);
        if (userOpt.isEmpty()) {
            return Optional.empty();
            }

        User user = userOpt.get();
        if (!user.getPasswordHash().equals(password)) {
            return Optional.empty();
        }

        return Optional.of(user);
    }

    public void changePassword(int userId, String oldPassword, String newPassword) throws Exception {
        User user = userDao.findById(userId);
        if (user == null) {
            throw new Exception("User not found with ID: " + userId);
        }

        if (!user.getPasswordHash().equals(oldPassword)) {
            throw new Exception("Old password does not match!");
        }

        boolean updated = userDao.updatePassword(userId, newPassword);
        if (!updated) {
            throw new Exception("Failed to update password in database!");
        }
    }

    @Override
    public List<User> getAllUsers() throws Exception {
        return userDao.findAll();
    }

    @Override
    public boolean removeUser(int id) throws Exception {
        return userDao.deleteById(id);
    }
}
