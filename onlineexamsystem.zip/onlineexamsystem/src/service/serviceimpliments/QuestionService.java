package service.serviceimpliments;

import dao.daoimplimentations.QuestionDAO;
import modellayer.Question;
import service.serviceinterface.IQuestionService;
import java.util.*;

public class QuestionService implements IQuestionService {

    private static volatile QuestionService instance;
    private final QuestionDAO questionDao = QuestionDAO.getInstance();

    public static QuestionService getInstance() {
        if (instance == null) {
            synchronized (QuestionService.class) {
                if (instance == null) instance = new QuestionService();
            }
        }
        return instance;
    }

    @Override
    public Question addQuestion(Question question) throws Exception {
        List<Question> existing = questionDao.findByExamId(question.getExamId());
        for (Question q : existing) {
            if (q.getText().equalsIgnoreCase(question.getText())) {
                throw new Exception("Duplicate question in the same exam.");
            }
        }
        return questionDao.save(question);
    }

    @Override
    public boolean updateQuestion(Question question) throws Exception {
        if (questionDao.findById(question.getId()).isEmpty()) {
            throw new Exception("Question not found for update.");
        }
        return questionDao.update(question);
    }

    @Override
    public boolean deleteQuestion(int id) throws Exception {
        return questionDao.deleteById(id);
    }

    @Override
    public List<Question> getQuestionsByExam(int examId) throws Exception {
        return questionDao.findByExamId(examId);
    }
}
