package service.serviceimpliments;

import dao.daoimplimentations.AnswerDAO;
import modellayer.Answer;
import modellayer.Result;
import service.serviceinterface.IAnswerService;

import java.util.*;

public class AnswerService implements IAnswerService {

     private static volatile AnswerService instance;
    private final AnswerDAO answerDao = AnswerDAO.getInstance();

    public static AnswerService getInstance() {
        if (instance == null) {
            synchronized (AnswerService.class) {
                if (instance == null) instance = new AnswerService();
            }
        }
        return instance;
    }

    @Override
    public Answer saveAnswer(Answer answer) throws Exception {
        List<Answer> answers = answerDao.findByUserAndExam(answer.getUserId(),answer.getExamId());
        for (Answer a : answers) {
            if (a.getQuestionId() == answer.getQuestionId()) {
                throw new Exception("Answer already exists for this question!");
            }
        }
        return answerDao.save(answer);
    }

    @Override
    public List<Answer> getAnswersByResultId(int userId,int examId) throws Exception {
        return answerDao.findByUserAndExam(userId,examId);
    }

    @Override
    public boolean clearAnswers(int userId,int examId) throws Exception {
        return answerDao.deleteByUserAndExam(userId,examId);
    }

}
