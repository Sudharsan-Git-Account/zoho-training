package service.serviceimpliments;

import dao.daoimplimentations.AnswerDAO;
import dao.daoimplimentations.OptionDAO;
import dao.daoimplimentations.QuestionDAO;
import dao.daoimplimentations.ResultDAO;
import java.util.*;
import modellayer.*;
import service.serviceinterface.IResultService;

public class ResultService implements IResultService {

    private static volatile ResultService instance;
    private final QuestionDAO questionDao = QuestionDAO.getInstance();
    private final OptionDAO optionDao = OptionDAO.getInstance();
    private final AnswerDAO answerDao = AnswerDAO.getInstance();
    private final ResultDAO resultDao = ResultDAO.getInstance();

    public static ResultService getInstance() {
        if (instance == null) {
            synchronized (ResultService.class) {
                if (instance == null) {
                    instance = new ResultService();
                }
            }
        }
        return instance;
    }
    @Override
    public Result evaluateExam(int userId, int examId) throws Exception {
        List<Question> questions = questionDao.findByExamId(examId);
        List<Answer> answers = answerDao.findByUserAndExam(userId, examId);

        int correctCount = 0;
        for (Question q : questions) {
            Optional<Answer> ua = answers.stream().filter(a -> a.getQuestionId() == q.getId()).findFirst();
            if (ua.isPresent()) {
                int sel = ua.get().getSelectedOptionId();
                for (Option o : optionDao.findByQuestionId(q.getId())) {
                    if (o.isCorrect() && o.getId() == sel) {
                        correctCount++;
                        break;
                    }
                }
            }
        }

        int totalQuestions = questions.size();
        int score = correctCount;
        int totalMarks = totalQuestions;

        Result result = new Result();
        result.setUserId(userId);
        result.setExamId(examId);
        result.setCorrectAnswers(correctCount);
        result.setTotalQuestions(totalQuestions);
        result.setScore(score);
        result.setTotalMarks(totalMarks); 

        Optional<Result> existing = resultDao.findByUserAndExam(userId, examId);
        if (existing.isPresent()) {
            result.setId(existing.get().getId());
            resultDao.update(result);
        } else {
            resultDao.save(result);
        }

        return result;
    }

    @Override
    public Optional<Result> getResultByUserAndExam(int userId, int examId) throws Exception {
        return resultDao.findByUserAndExam(userId, examId);
    }

    public List<Result> getResultsByUserId(int userId) throws Exception {
        return resultDao.findByUserId(userId);
    }

    public List<Result> getAllResults() throws Exception {
        return resultDao.findAll();
    }
}
