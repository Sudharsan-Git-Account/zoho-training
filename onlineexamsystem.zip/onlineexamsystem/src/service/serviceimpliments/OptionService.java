package service.serviceimpliments;

import dao.daoimplimentations.OptionDAO;
import modellayer.Option;
import service.serviceinterface.IOptionService;

import java.util.*;

public class OptionService implements IOptionService {

    private static volatile OptionService instance;
    private final OptionDAO optionDao = OptionDAO.getInstance();

    public static OptionService getInstance() {
        if (instance == null) {
            synchronized (OptionService.class) {
                if (instance == null) instance = new OptionService();
            }
        }
        return instance;
    }

    @Override
    public Option addOption(Option option) throws Exception {
        List<Option> existing = optionDao.findByQuestionId(option.getQuestionId());
        if (option.isCorrect()) {
            for (Option o : existing) {
                if (o.isCorrect()) {
                    throw new Exception("Question already has a correct option!");
                }
            }
        }
        return optionDao.save(option);
    }

    @Override
    public List<Option> getOptionsByQuestion(int questionId) throws Exception {
        return optionDao.findByQuestionId(questionId);
    }

    @Override
    public boolean removeOptionsByQuestion(int questionId) throws Exception {
        return optionDao.deleteByQuestionId(questionId);
    }
}
