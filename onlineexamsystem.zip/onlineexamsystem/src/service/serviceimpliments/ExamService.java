package service.serviceimpliments;

import dao.daoimplimentations.AnswerDAO;
import dao.daoimplimentations.ExamDAO;
import dao.daoimplimentations.OptionDAO;
import dao.daoimplimentations.QuestionDAO;
import dao.daoimplimentations.ResultDAO;
import modellayer.*;
import service.serviceinterface.IExamService;
import java.util.*;

public class ExamService implements IExamService {

    private static volatile ExamService instance;
    private final ExamDAO examDao = ExamDAO.getInstance();
    private final QuestionDAO questionDao = QuestionDAO.getInstance();
    private final OptionDAO optionDao = OptionDAO.getInstance();
    private final AnswerDAO answerDao = AnswerDAO.getInstance();
    private final ResultDAO resultDao = ResultDAO.getInstance();
    
    public static ExamService getInstance() {
        if (instance == null) {
            synchronized (ExamService.class) {
                if (instance == null) instance = new ExamService();
            }
        }
        return instance;
    }

    @Override
    public Optional<Exam> getExamById(int id) throws Exception {
        return examDao.findById(id);
    }

    @Override
    public List<Exam> getAllExams() throws Exception {
        return examDao.findAll();
    }


    @Override
    public Exam createExam(Exam exam) throws Exception {
        List<Exam> allExams = examDao.findAll();
        for (Exam e : allExams) {
            if (e.getTitle().equalsIgnoreCase(exam.getTitle())) {
                throw new Exception("Exam with title '" + exam.getTitle() + "' already exists.");
            }
        }
        return examDao.save(exam);
    }

    @Override
    public boolean removeExam(int id) throws Exception {
        return examDao.deleteById(id);
    }

    @Override
    public boolean updateExam(Exam exam) throws Exception {
        if (examDao.findById(exam.getId()).isEmpty()) {
            throw new Exception("Exam not found for update");
        }
        return examDao.update(exam);
    }

    public List<Question> getQuestionsByExamId(int examId)throws Exception  {
        return questionDao.findByExamId(examId);
    }

    public List<Option> getOptionsByQuestionId(int questionId) {
        try {
            return optionDao.findByQuestionId(questionId);
        }catch(Exception e){
            e.printStackTrace();
            return new ArrayList<>();
        }
    }

    public void saveAnswer(int userId, int examId, int questionId, int selectedOptionId) {
        answerDao.save(userId, examId, questionId, selectedOptionId);
    }

    public Result evaluateAndSaveResult(int userId, int examId) throws Exception {
        List<Question> questions = questionDao.findByExamId(examId);
        if (questions.isEmpty()) throw new Exception("No questions for exam");
        List<Answer> answers = answerDao.findByUserAndExam(userId, examId);

        int correctCount = 0;
        for (Question q : questions) {
            List<Option> opts = optionDao.findByQuestionId(q.getId());
            Optional<Answer> ua = answers.stream().filter(a -> a.getQuestionId() == q.getId()).findFirst();
            if (ua.isPresent()) {
                int selected = ua.get().getSelectedOptionId();
                for (Option o : opts) {
                    if (o.isCorrect() && o.getId() == selected) {
                        correctCount++;
                        break;
                    }
                }
            }
        }

        int totalQuestions = questions.size();
        int score = totalQuestions == 0 ? 0 : (int) Math.round((correctCount * 100.0) / totalQuestions);

        Result res = new Result();
        res.setUserId(userId);
        res.setExamId(examId);
        res.setCorrectAnswers(correctCount);
        res.setTotalQuestions(totalQuestions);
        res.setScore(correctCount);
        res.setTotalMarks(totalQuestions == 0 ? 0 : totalQuestions);

        Optional<Result> existing = resultDao.findByUserAndExam(userId, examId);
        if (existing.isPresent()) {
            res.setId(existing.get().getId());
            resultDao.update(res);
        } else {
            resultDao.save(res);
        }
        return res;
    }
}

