package dao.daoimplimentations;

import dao.daointerfaces.IQuestionDAO;
import utils.DBConfig;
import modellayer.Question;

import java.sql.*;
import java.util.*;

public class QuestionDAO implements IQuestionDAO {

     private static volatile QuestionDAO instance;

    public static QuestionDAO getInstance() {
        if (instance == null) {
            synchronized (QuestionDAO.class) {
                if (instance == null) instance = new QuestionDAO();
            }
        }
        return instance;
    }

    @Override
    public Optional<Question> findById(int id) throws Exception {
        String sql = "SELECT * FROM questions WHERE id = ?";
        try (Connection conn = DBConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
           try(ResultSet rs = ps.executeQuery()){
            if (rs.next()){
             return Optional.of(mapQuestion(rs));
            }
           }
        }
        return Optional.empty();
    }

    @Override
    public List<Question> findByExamId(int examId) throws Exception {
        List<Question> list = new ArrayList<>();
        String sql = "SELECT * FROM questions WHERE exam_id = ? ORDER BY id";
        try (Connection conn = DBConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, examId);
            try(ResultSet rs = ps.executeQuery()){
            while (rs.next()) {
                list.add(mapQuestion(rs));
            }
            }
        }
        return list;
    }

    @Override
    public Question save(Question question) throws Exception {
        String sql = "INSERT INTO questions (exam_id, text, marks, question_order) VALUES (?, ?, ?, ?) RETURNING id";
        try (Connection conn = DBConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, question.getExamId());
            ps.setString(2, question.getText());
            ps.setInt(3, question.getMarks());
            ps.setInt(4,question.getQuestionOrder());
            try(ResultSet rs = ps.executeQuery()){
            if (rs.next()) {
                question.setId(rs.getInt("id"));
            }
            }
        }
        return question;
    }

    @Override
    public boolean update(Question question) throws Exception {
        String sql = "UPDATE questions SET text = ?, marks = ? WHERE id = ?";
        try (Connection conn = DBConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, question.getText());
            ps.setInt(2, question.getMarks());
            ps.setInt(3, question.getId());
            return ps.executeUpdate() > 0;
        }
    }

    @Override
    public boolean deleteById(int id) throws Exception {
        String sql = "DELETE FROM questions WHERE id = ?";
        try (Connection conn = DBConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        }
    }

    private Question mapQuestion(ResultSet rs) throws SQLException {
        Question q = new Question();
        q.setId(rs.getInt("id"));
        q.setExamId(rs.getInt("exam_id"));
        q.setText(rs.getString("text"));
        q.setMarks(rs.getInt("marks"));
        q.setQuestionOrder(rs.getInt("question_order"));
        return q;
    }
}
