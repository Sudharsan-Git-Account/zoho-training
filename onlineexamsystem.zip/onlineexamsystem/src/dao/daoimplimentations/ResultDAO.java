package dao.daoimplimentations;

import dao.daointerfaces.IResultDAO;
import java.sql.*;
import java.util.*;
import modellayer.Result;
import utils.DBConfig;

public class ResultDAO implements IResultDAO {

    private static  ResultDAO instance;

    public static ResultDAO getInstance() {
        if (instance == null) {
            synchronized (ResultDAO.class) {
                if (instance == null) instance = new ResultDAO();
            }
        }
        return instance;
    }

    @Override
    public Optional<Result> findByUserAndExam(int userId, int examId) throws Exception {
        String sql = """
         SELECT r.*, e.title AS exam_title FROM results r JOIN exams e ON r.exam_id = e.id WHERE r.user_id = ? AND r.exam_id = ? """;

        try (Connection conn = DBConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            ps.setInt(2, examId);
            try(ResultSet rs = ps.executeQuery()){
            if (rs.next()) {
                return Optional.of(mapResult(rs));
            }
            }
        }
        return Optional.empty();
    }

    public List<Boolean> getAnswerCorrectness(int userId, int examId) throws Exception {
        List<Boolean> correctness = new ArrayList<>();
        String sql = """
        SELECT o.is_correct
        FROM answers a
        JOIN options o ON a.selected_option_id = o.id
        WHERE a.user_id = ? AND a.exam_id = ?
    """;
        try (Connection conn = DBConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            ps.setInt(2, examId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    correctness.add(rs.getBoolean("is_correct"));
                }
            }
        }
        return correctness;
    }


    public List<Result> findByUserId(int userId) throws Exception {
        List<Result> results = new ArrayList<>();
        String sql = """
    SELECT r.*, e.title AS exam_title FROM results r JOIN exams e ON r.exam_id = e.id WHERE r.user_id = ? ORDER BY r.exam_id """;

        try (Connection conn = DBConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    results.add(mapResult(rs));
                }
            }
        }
        return results;
    }


    @Override
    public List<Result> findAll() throws Exception {
        List<Result> results = new ArrayList<>();
        String sql = "SELECT r.*, e.title AS exam_title \r\n FROM results r\r\n JOIN exams e ON r.exam_id = e.id\r\n ORDER BY r.id";
        try (Connection conn = DBConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                results.add(mapResult(rs));
            }
        }
        return results;
    }

    @Override
    public Result save(Result result) throws Exception {
        String sql = "INSERT INTO results (user_id, exam_id, score, total_marks, correct_answers, total_questions) VALUES (?, ?, ?, ?, ?, ?) RETURNING id";
        try (Connection conn = DBConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, result.getUserId());
            ps.setInt(2, result.getExamId());
            ps.setInt(3, result.getScore());
            ps.setInt(4, result.getTotalMarks());
            ps.setInt(5, result.getCorrectAnswers());
            ps.setInt(6, result.getTotalQuestions());
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    result.setId(rs.getInt("id"));
                }
            }
        }
        return result;
    }

    @Override
    public boolean update(Result result) throws Exception {
        String sql = "UPDATE results SET score = ?, total_marks = ?, correct_answers = ?, total_questions = ? WHERE user_id = ? AND exam_id = ?";
        try (Connection conn = DBConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, result.getScore());
            ps.setInt(2, result.getTotalMarks());
            ps.setInt(3, result.getCorrectAnswers());
            ps.setInt(4, result.getTotalQuestions());
            ps.setInt(5, result.getUserId());
            ps.setInt(6,result.getExamId());

            return ps.executeUpdate() > 0;
        }
    }

    private Result mapResult(ResultSet rs) throws SQLException {
        Result r = new Result();
        r.setId(rs.getInt("id"));
        r.setUserId(rs.getInt("user_id"));
        r.setExamId(rs.getInt("exam_id"));
        r.setScore(rs.getInt("score"));
        r.setTotalMarks(rs.getInt("total_marks"));
        r.setCorrectAnswers(rs.getInt("correct_answers"));
        r.setTotalQuestions(rs.getInt("total_questions"));
        r.setPassOrFail(r.getScore(), r.getTotalMarks());
        String examTitle = rs.getString("exam_title");
        if(examTitle != null){
            r.setExamTitle(examTitle);
        }   
        return r;
    }
}
