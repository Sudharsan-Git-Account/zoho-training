package dao.daoimplimentations;

import dao.daointerfaces.IOptionDAO;
import java.sql.*;
import java.util.*;
import modellayer.Option;
import utils.DBConfig;

public class OptionDAO implements IOptionDAO {

    private static volatile OptionDAO instance;

    public static OptionDAO getInstance() {
        if (instance == null) {
            synchronized (OptionDAO.class) {
                if (instance == null) instance = new OptionDAO();
            }
        }
        return instance;
    }

    @Override
    public List<Option> findByQuestionId(int questionId) throws Exception {
        List<Option> list = new ArrayList<>();
        String sql = "SELECT * FROM options WHERE question_id = ? ORDER BY id";
        try (Connection conn = DBConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, questionId);
            try(ResultSet rs = ps.executeQuery()){
            while (rs.next()) {
                list.add(mapOption(rs));
            }
            }
        }
        return list;
    }

    public Option findById(int id) throws Exception {
    String sql = "SELECT * FROM options WHERE id = ?";
    try (Connection conn = DBConfig.getConnection();
         PreparedStatement ps = conn.prepareStatement(sql)) {

        ps.setInt(1, id);

        try (ResultSet rs = ps.executeQuery()) {
            if (rs.next()) {
                return mapOption(rs);
            }
        }
    }
    return null; 
    }

    @Override
    public Option save(Option option) throws Exception {
        String sql = "INSERT INTO options (question_id, text, is_correct) VALUES (?, ?, ?) RETURNING id";
        try (Connection conn = DBConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, option.getQuestionId());
            ps.setString(2, option.getText());
            ps.setBoolean(3, option.isCorrect());
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    option.setId(rs.getInt("id"));
                    return option;
                } else {
                    throw new SQLException("Failed to insert option, no ID returned.");
                }
            }
        }
    }

    public boolean update(Option option) throws Exception {
        String sql = "UPDATE options SET text = ?, is_correct = ? WHERE id = ?";
        try (Connection conn = DBConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, option.getText());
            ps.setBoolean(2, option.isCorrect());
            ps.setInt(3, option.getId());
            return ps.executeUpdate() > 0;
        }
    }

    @Override
    public boolean deleteByQuestionId(int questionId) throws Exception {
        String sql = "DELETE FROM options WHERE question_id = ?";
        try (Connection conn = DBConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, questionId);
            return ps.executeUpdate() > 0;
        }
    }

    private Option mapOption(ResultSet rs) throws SQLException {
        Option o = new Option();
        o.setId(rs.getInt("id"));
        o.setQuestionId(rs.getInt("question_id"));
        o.setText(rs.getString("text"));
        o.setCorrect(rs.getBoolean("is_correct"));
        return o;
    }
}
