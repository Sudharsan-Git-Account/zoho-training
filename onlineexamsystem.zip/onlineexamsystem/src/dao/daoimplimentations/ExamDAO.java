package dao.daoimplimentations;

import dao.daointerfaces.IExamDAO;
import modellayer.Exam;
import modellayer.Question;
import utils.DBConfig;

import java.sql.*;
import java.util.*;

public class ExamDAO implements IExamDAO {

    private static volatile ExamDAO instance;

    public static ExamDAO getInstance() {
        if (instance == null) {
            synchronized (ExamDAO.class) {
                if (instance == null) instance = new ExamDAO();
            }
        }
        return instance;
    }

    @Override
    public Optional<Exam> findById(int id) throws Exception {
        String query = "SELECT * FROM exams WHERE id = ?";
        try (Connection conn = DBConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return Optional.of(mapExam(rs));
                }
            }
        }
        return Optional.empty();
    }

    @Override
    public List<Exam> findAll() throws Exception {
        List<Exam> exams = new ArrayList<>();
        String query = "SELECT * FROM exams ORDER BY id";
        try (Connection conn = DBConfig.getConnection();
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(query)) {
            while (rs.next()) {
                exams.add(mapExam(rs));
            }
        }
        return exams;
    }

    @Override
    public Exam save(Exam exam) throws Exception {
        String query = "INSERT INTO exams (title, description, total_marks, duration_minutes, created_by) VALUES (?, ?, ?, ?, ?) RETURNING id";
        try (Connection conn = DBConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setString(1, exam.getTitle());
            ps.setString(2, exam.getDescription());
            ps.setInt(3, exam.getTotalMarks());
            ps.setInt(4, exam.getDurationMinutes());
            ps.setInt(5, exam.getCreatedBy()); // FIXED — now int
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    exam.setId(rs.getInt("id"));
                }
            }
        }
        return exam;
    }


    public void addQuestionToExam(Question question) throws Exception {
        String sql = "INSERT INTO questions (exam_id, question_text, correct_option_id, marks) VALUES (?, ?, ?, ?)";
        try (Connection con = DBConfig.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, question.getExamId());
            ps.setString(2, question.getText());
            ps.setInt(3, question.getExamId());
            ps.setInt(4, question.getMarks());
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new Exception("Error adding question to exam: " + e.getMessage(), e);
        }
    }

    @Override
    public boolean update(Exam exam) throws Exception {
        String query = "UPDATE exams SET title = ?, description = ?, total_marks = ?, duration_minutes = ?, created_by = ? WHERE id = ?";
        try (Connection conn = DBConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setString(1, exam.getTitle());
            ps.setString(2, exam.getDescription());
            ps.setInt(3, exam.getTotalMarks());
            ps.setInt(4, exam.getDurationMinutes());
            ps.setInt(5, exam.getCreatedBy()); // FIXED — int instead of String
            ps.setInt(6, exam.getId());
            return ps.executeUpdate() > 0;
        }
    }

    @Override
    public boolean deleteById(int id) throws Exception {
        String query = "DELETE FROM exams WHERE id = ?";
        try (Connection conn = DBConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        }
    }

    private Exam mapExam(ResultSet rs) throws SQLException {
        Exam e = new Exam();
        e.setId(rs.getInt("id"));
        e.setTitle(rs.getString("title"));
        e.setDescription(rs.getString("description"));
        e.setTotalMarks(rs.getInt("total_marks"));
        e.setDurationMinutes(rs.getInt("duration_minutes"));
        e.setCreatedBy(rs.getInt("created_by"));
        return e;
    }
}
