package dao.daoimplimentations;

import dao.daointerfaces.IAnswerDAO;
import utils.DBConfig;
import modellayer.Answer;

import java.sql.*;
import java.util.*;

public class AnswerDAO implements IAnswerDAO {

    private static volatile AnswerDAO instance;

    public static AnswerDAO getInstance() {
        if (instance == null) {
            synchronized (AnswerDAO.class) {
                if (instance == null) instance = new AnswerDAO();
            }
        }
        return instance;
    }
    @Override
    public List<Answer> findByUserAndExam(int userId, int examId) throws Exception {
        List<Answer> answers = new ArrayList<>();
        String sql = "SELECT * FROM answers WHERE user_id = ? AND exam_id = ? ORDER BY question_id";

        try (Connection conn = DBConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            ps.setInt(2, examId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    answers.add(mapAnswer(rs));
                }
            }
        }
        return answers;
    }


    @Override
    public Answer save(Answer answer) throws Exception {
        String sql = "INSERT INTO answers (userId,examId, question_id, selected_option_id) VALUES (?, ?, ?, ?) RETURNING id";
        try (Connection conn = DBConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, answer.getUserId());
            ps.setInt(1, answer.getExamId());
            ps.setInt(2, answer.getQuestionId());
            ps.setInt(3, answer.getSelectedOptionId());
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    answer.setId(rs.getInt("id"));
                }
            }
        }
        return answer;
    }

    public void save(int userId, int examId, int questionId, int selectedOptionId) {
        String sql = "INSERT INTO answers (user_id, exam_id, question_id, selected_option_id) VALUES (?, ?, ?, ?)";
        try (Connection conn = DBConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            ps.setInt(2, examId);
            ps.setInt(3, questionId);
            ps.setInt(4, selectedOptionId);
            ps.executeUpdate();
        } catch (SQLException e) {
            System.err.println("Error saving answer: " + e.getMessage());
        }
    }


    public boolean update(Answer answer) throws Exception {
        String sql = "UPDATE answers SET selected_option_id = ? WHERE id = ? AND result_id = ? AND question_id = ?";
        try (Connection conn = DBConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, answer.getSelectedOptionId());
            ps.setInt(2, answer.getId());
            ps.setInt(3, answer.getResultId());
            ps.setInt(4, answer.getQuestionId());
            return ps.executeUpdate() > 0;
        }
    }

    @Override
    public boolean deleteByUserAndExam(int userId, int examId) throws Exception {
        String sql = "DELETE FROM answers WHERE user_id = ? AND exam_id = ?";
        try (Connection conn = DBConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            ps.setInt(2, examId);
            return ps.executeUpdate() > 0;
        }
    }
        private Answer mapAnswer(ResultSet rs) throws SQLException {
        Answer a = new Answer();
        a.setId(rs.getInt("id"));
        a.setUserId(rs.getInt("user_id"));
        a.setExamId(rs.getInt("exam_id"));
        a.setQuestionId(rs.getInt("question_id"));
        a.setSelectedOptionId(rs.getInt("selected_option_id"));
        return a;
    }

}
