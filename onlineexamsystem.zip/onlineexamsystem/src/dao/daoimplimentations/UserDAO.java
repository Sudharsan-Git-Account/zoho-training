package dao.daoimplimentations;

import dao.daointerfaces.IUserDAO;
import java.sql.*;
import java.util.*;
import modellayer.User;
import utils.DBConfig;

public class UserDAO implements IUserDAO {

    private static volatile UserDAO instance;

    public static UserDAO getInstance() {
       if (instance == null) {
            synchronized (UserDAO.class) {
                if (instance == null){
                     instance = new UserDAO();
                }
            }
        }
        return instance;
    }

    @Override
    public User findById(int id) throws Exception {
        String query = "SELECT * FROM users WHERE id = ?";
        try (Connection conn = DBConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setInt(1, id);
            try(ResultSet rs = ps.executeQuery()){
                if (rs.next()) {
                    return mapUser(rs);

                }
            }
        }
        return null;
    }

    @Override
    public Optional<User> findByUsername(String username) throws Exception {
        String query = "SELECT * FROM users WHERE username = ?";
        try (Connection conn = DBConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setString(1, username);
            try(ResultSet rs = ps.executeQuery()){
                if (rs.next()) {
                    User u = mapUser(rs);
                    return Optional.of(u);
                }
            }
        }
        return Optional.empty();
    }

    @Override
    public List<User> findAll() throws Exception {
        List<User> users = new ArrayList<>();
        String query = "SELECT * FROM users ORDER BY id";
        try (Connection conn = DBConfig.getConnection();
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(query)) {
            while (rs.next()) {
                users.add(mapUser(rs));
            }
        }
        return users;
    }

    @Override
    public User save(User user) throws Exception {
        String query = "INSERT INTO users (username, password_hash,  user_name , role) VALUES (?, ?, ?, ?::user_role)";
        try (Connection conn = DBConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(query, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, user.getUsername());
            ps.setString(2, user.getPasswordHash());
            ps.setString(3, user.getFullName());
            ps.setString(4, user.getRole());
            ps.executeUpdate();
            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) {
                    user.setId(rs.getInt(1));
                }
            }
        }
        return user;
    }

    public boolean update(User user) throws Exception {
        String query = "UPDATE users SET username = ?, password_hash = ?, user_name = ?, role = ?::user_role WHERE id = ?";
        try (Connection conn = DBConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setString(1, user.getUsername());
            ps.setString(2, user.getPasswordHash());
            ps.setString(3, user.getFullName());
            ps.setString(4, user.getRole());
            ps.setInt(5, user.getId());
            return ps.executeUpdate() > 0;
        }
    }

    public boolean updatePassword(int userId, String newPassword) throws Exception {
        String sql = "UPDATE users SET password_hash = ? WHERE id = ?";
        try (Connection conn = DBConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, newPassword);
            ps.setInt(2, userId);
            int rows = ps.executeUpdate();
            return rows > 0;
        } catch (SQLException e) {
            throw new Exception("Database error while updating password: " + e.getMessage(), e);
        }
    }


    @Override
    public boolean deleteById(int id) throws Exception {
        String query = "DELETE FROM users WHERE id = ?";
        try (Connection conn = DBConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        }
    }

    private User mapUser(ResultSet rs) throws SQLException {
        User u = new User();
        u.setId(rs.getInt("id"));
        u.setUsername(rs.getString("username"));
        u.setPasswordHash(rs.getString("password_hash"));
        u.setFullName(rs.getString("user_name"));
        u.setRole(rs.getString("role"));
        return u;
    }
}

