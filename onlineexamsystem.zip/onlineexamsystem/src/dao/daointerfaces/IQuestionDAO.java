package dao.daointerfaces;

import modellayer.Question;
import java.util.*;

public interface IQuestionDAO {
    Optional<Question> findById(int id) throws Exception;
    List<Question> findByExamId(int examId) throws Exception;
    Question save(Question question) throws Exception;
    boolean update(Question question) throws Exception;
    boolean deleteById(int id) throws Exception;
}
