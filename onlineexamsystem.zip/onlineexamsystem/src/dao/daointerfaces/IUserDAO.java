package dao.daointerfaces;

import modellayer.User;
import java.util.*;

public interface IUserDAO {
    User findById(int id) throws Exception;
    Optional<User> findByUsername(String username) throws Exception;
    List<User> findAll() throws Exception;
    User save(User user) throws Exception;
    boolean update(User user) throws Exception;
    boolean deleteById(int id) throws Exception;
}
