package dao.daointerfaces;

import modellayer.Exam;
import java.util.*;

public interface IExamDAO {
    Exam save(Exam exam) throws Exception;
    Optional<Exam> findById(int id) throws Exception;
    List<Exam> findAll() throws Exception;
    boolean update(Exam exam) throws Exception;
    boolean deleteById(int id) throws Exception;
}
