package dao.daointerfaces;

import modellayer.Answer;
import java.util.*;

public interface IAnswerDAO {
    List<Answer> findByUserAndExam(int userId, int examId) throws Exception;
    Answer save(Answer answer) throws Exception;
    boolean update(Answer answer) throws Exception;
    boolean deleteByUserAndExam(int userId,int examId) throws Exception;
}
