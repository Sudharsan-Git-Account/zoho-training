package dao.daointerfaces;

import java.util.*;
import modellayer.Option;

public interface IOptionDAO {
    List<Option> findByQuestionId(int questionId) throws Exception;
    Option findById(int id) throws Exception;
    Option save(Option option) throws Exception;
    boolean update(Option option) throws Exception;
    boolean deleteByQuestionId(int questionId) throws Exception;
}
