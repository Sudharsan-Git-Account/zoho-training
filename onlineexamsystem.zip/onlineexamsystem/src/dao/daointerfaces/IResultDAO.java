package dao.daointerfaces;
import java.util.*;
import modellayer.Result;

public interface IResultDAO {
    Optional<Result> findByUserAndExam(int userId, int examId) throws Exception;
    Result save(Result result) throws Exception;
    List<Result> findAll()throws Exception;
    boolean update(Result result) throws Exception;
}
