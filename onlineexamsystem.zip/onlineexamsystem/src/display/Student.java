package display;

import modellayer.User;
import utils.Inpututil;
import view.Studentview;

public class Student {

    private final Studentview studentview = new Studentview();

    public void displayStudentMenu(User student) {
        while (true) {
            System.out.println("\n==============================");
            System.out.println("        STUDENT MENU");
            System.out.println("==============================");
            System.out.println("1. Take Exam");
            System.out.println("2. View My Results");
            System.out.println("3. View Available Exams");
            System.out.println("4. Search Exam by Title");
            System.out.println("5. View My Profile");
            System.out.println("6. Change Password");
            System.out.println("7. Logout");

            int choice = Inpututil.getIntInput("Enter choice: ", 1, 7);

            switch (choice) {
                case 1 -> studentview.takeExam(student);
                case 2 -> studentview.viewResult(student);
                case 3 -> studentview.viewAvailableExams();
                case 4 -> studentview.searchExam();
                case 5 -> studentview.viewProfile(student);
                case 6 -> studentview.changePassword(student);
                case 7 -> {
                    System.out.println("Logging out...");
                    return;
                }
                default -> System.out.println("Invalid choice. Please try again.");
            }
            Inpututil.pause();
        }
    }
}
