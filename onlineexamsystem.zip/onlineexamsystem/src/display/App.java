package display;

import utils.CreateTable;

public class App {
    public static void main(String[] args) {
        MainMenu m = new MainMenu();
        CreateTable ct = new CreateTable();
        ct.Sql();
        m.displayMainMenu();
    }
}
