package display;

import controller.UserController;
import utils.Inpututil;

public class MainMenu {
    private static UserController userController = UserController.getInstance();

    public void displayMainMenu() {
        while (true) {
            System.out.println("\n==============================");
            System.out.println("     ONLINE EXAM SYSTEM");
            System.out.println("==============================");
            System.out.println("1. Login");
            System.out.println("2. Register");
            System.out.println("3. Exit");

            int choice = Inpututil.readInt("Enter your choice: ");

            switch (choice) {
                case 1:
                    new Login().displayLogin();
                    break;

                case 2:
                    new Register().displayRegistration();
                    break;

                case 3:
                    System.out.println("--------------------------------------------------------------");
                    System.out.println("       Thank you for using Online Exam System!");
                    System.out.println("--------------------------------------------------------------");
                    System.exit(0);
                    break;

                default:
                    System.out.println("Invalid choice. Please try again.");
                    break;
            }
        }
    }
}
