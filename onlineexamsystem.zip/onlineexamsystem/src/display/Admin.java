package display;
import utils.Inpututil;
import view.Adminview;

public class Admin {

    private final Adminview adminView = new Adminview();

    public void displayAdminMenu() {
        while (true) {
            System.out.println("\n==============================");
            System.out.println("         ADMIN MENU");
            System.out.println("==============================");
            System.out.println("1. Create Exam");
            System.out.println("2. View Exams");
            System.out.println("3. Update Exam");
            System.out.println("4. Delete Exam");
            System.out.println("5. Add Question to Exam");
            System.out.println("6. View All Students");
            System.out.println("7. View All Results");
            System.out.println("8. Search Exam by Title");
            System.out.println("9. Logout");

            int choice = Inpututil.getIntInput("Enter choice: ", 1, 9);

            switch (choice) {
                case 1 -> adminView.createExam();
                case 2 -> adminView.viewExams();
                case 3 -> adminView.updateExam();
                case 4 -> adminView.deleteExam();
                case 5 -> adminView.addQuestionToExam();
                case 6 -> adminView.viewAllStudents();
                case 7 -> adminView.viewAllResults();
                case 8 -> adminView.searchExamByTitle();
                case 9 -> {
                    System.out.println("Logging out...");
                    return;
                }
            }
            Inpututil.pause();
        }
    }
}
