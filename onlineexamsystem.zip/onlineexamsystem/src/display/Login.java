package display;

import controller.UserController;
import modellayer.User;
import utils.Inpututil;

public class Login {
    private UserController userController = UserController.getInstance();

    public void displayLogin() {
        System.out.println("\n--- Login ---");
        String username = Inpututil.readString("E-mail: ");
        String password = Inpututil.readString("Password: ");

        User user = userController.login(username, password);

        if (user == null) {
            System.out.println("Invalid E-mail or password. Try again!");
            return;
        }

        if (user.getRole().equalsIgnoreCase("ADMIN")) {
            new Admin().displayAdminMenu();
        } else {
            new Student().displayStudentMenu(user);
        }
    }
}
