package display;

import utils.Inpututil;
import controller.UserController;
import modellayer.User;

public class Register {
    private UserController userController = UserController.getInstance();

    public void displayRegistration() {
        System.out.println("\n--- Register New Student ---");
        String username = Inpututil.readString("Enter your E-mail: ");
        String password = Inpututil.readString("Enter your Password: ");
        String fullName = Inpututil.readString("Enter your full name: ");

        try {
            userController.registerUser(username,password,fullName, "STUDENT");
            System.out.println("Registration successful! You can now log in.");
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}
