package modellayer;

public class Option {
    private int id;
    private int questionId;
    private String text;
    private boolean isCorrect;

    public Option(){
    }
    
    public Option(int id, int questionId, String text, boolean isCorrect) {
        this.id = id;
        this.questionId = questionId;
        this.text = text;
        this.isCorrect = isCorrect;
    }

    public int getId() { 
        return id; 
    }
    public void setId(int id) { 
        this.id = id; 
    }

    public int getQuestionId() { 
        return questionId; 
    }
    public void setQuestionId(int questionId) { 
        this.questionId = questionId; 
    }

    public String getText() { 
        return text; 
    }
    public void setText(String text) { 
        this.text = text; 
    }

    public boolean isCorrect() { 
        return isCorrect; 
    }
    public void setCorrect(boolean isCorrect) { 
        this.isCorrect = isCorrect; 
    }

    @Override
    public String toString() {
        return "Option [id=" + id + ", text=" + text + ", correct=" + isCorrect + "]";
    }
}
