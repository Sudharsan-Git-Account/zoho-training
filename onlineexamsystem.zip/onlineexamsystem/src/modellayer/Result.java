package modellayer;

import java.time.LocalDateTime;

public class Result {
    private int id;
    private int examId;
    private int userId;
    private int score;
    private String examTitle;
    private int correctAnswers;
    private int totalQuestions;
    private int totalMarks;
    private boolean passOrFail;
    private LocalDateTime takenAt;

    public Result() {
    }

    public Result(int id, int examId,int correctAnswers,int totalQuestions, int userId, int score,String examTitle,boolean passOrFail, int totalMarks, LocalDateTime takenAt) {
        this.id = id;
        this.examId = examId;
        this.correctAnswers = correctAnswers;
        this.totalQuestions = totalQuestions;   
        this.userId = userId;
        this.score = score;
        this.examTitle = examTitle;
        this.passOrFail = passOrFail;
        this.totalMarks = totalMarks;
        this.takenAt = takenAt;
    }

    public int getId() { 
        return id; 
    }
    public void setId(int id) { 
        this.id = id; 
    }

    public int getCorrectAnswers() { 
        return correctAnswers; 
    }   
    public void setCorrectAnswers(int correctAnswers) { 
        this.correctAnswers = correctAnswers; 
    }

    public int getTotalQuestions() { 
        return totalQuestions; 
    }   
    public void setTotalQuestions(int totalQuestions) { 
        this.totalQuestions = totalQuestions; 
    }
    
    public int getExamId() { 
        return examId; 
    }
    public void setExamId(int examId) { 
        this.examId = examId; 
    }

    public int getUserId() { 
        return userId; 
    }
    public void setUserId(int userId) { 
        this.userId = userId; 
    }

    public int getScore() { 
        return score; 
    }
    public void setScore(int score) { 
        this.score = score; 
    }

    public String getExamTitle() {
        return examTitle;
    }
    public void setExamTitle(String examTitle) {
        this.examTitle = examTitle;
    }   

    public boolean getPassOrFail() {
        return passOrFail;
    }
   public void setPassOrFail(int score, int totalMarks) {
    if (totalMarks <= 0) {
        this.passOrFail = false;
        return;
    }
    double percentage = (score * 100.0) / totalMarks;
    this.passOrFail = (percentage >= 40.0);
    }

    public int getTotalMarks() {
        return totalMarks; 
    }
    public void setTotalMarks(int totalMarks) { 
        this.totalMarks = totalMarks; 
    }

    public LocalDateTime getTakenAt() { 
        return takenAt; 
    }
    public void setTakenAt(LocalDateTime takenAt) { 
        this.takenAt = takenAt; 
    }

    @Override
public String toString() {
    double pct = (totalMarks > 0) ? (score * 100.0) / totalMarks : 0.0;
    return String.format("Result [examId=%d, userId=%d, score=%d/%d (%.2f%%), %s]",
            examId, userId, score, totalMarks, pct, (passOrFail ? "Pass" : "Fail"));
}

}
