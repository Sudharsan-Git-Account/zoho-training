package modellayer;

import view.Adminview;

import java.time.LocalDateTime;

public class Exam {
    private int id;
    private String title;
    private String description;
    private int totalMarks;
    private int durationMinutes;
    private int createdBy;
    private LocalDateTime createdAt;

    public Exam() {
    }   

    public Exam(int id, String title, String description, int totalMarks, int durationMinutes, int createdBy, LocalDateTime createdAt) {
        this.id = id;
        this.title = title;
        this.description = description;
        this.totalMarks = totalMarks;
        this.durationMinutes = durationMinutes;
        this.createdBy = createdBy;
        this.createdAt = createdAt;
    }

    public int getId() { 
        return id; 
    }
    public void setId(int id) { 
        this.id = id; 
    }

    public String getTitle() { 
        return title; 
    }
    public void setTitle(String title) { 
        this.title = title; 
    }

    public String getDescription() { 
        return description; 
    }
    public void setDescription(String description) { 
        this.description = description; 
    }

    public int getTotalMarks() { 
        return totalMarks; 
    }
    public void setTotalMarks(int totalMarks) { 

        this.totalMarks = totalMarks;
    }

    public int getDurationMinutes() { 
        return durationMinutes; 
    }
    public void setDurationMinutes(int durationMinutes) { 

        this.durationMinutes = durationMinutes;
    }

    public int getCreatedBy() {
        return createdBy; 
    }
    public void setCreatedBy(int createdBy) {

        this.createdBy = createdBy;
    }

    public LocalDateTime getCreatedAt() { 
        return createdAt; 
    }
    public void setCreatedAt(LocalDateTime createdAt) { 
        this.createdAt = createdAt; 
    }

    @Override
    public String toString() {
        return "Exam [id=" + id + ", title=" + title + ", totalMarks=" + totalMarks + ", duration=" + durationMinutes + " mins]";
    }
}
