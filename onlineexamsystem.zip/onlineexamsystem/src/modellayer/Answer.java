package modellayer;

public class Answer {
    private int id;
    private int resultId;
    private int examId;
    private int userId;
    private int optionId;
    private int questionId;
    private int selectedOptionId;

    public Answer() {
    }   
    
    public Answer(int id, int resultId,int examId, int questionId,int userId,int optionId,int selectedOptionId) {
        this.id = id;
        this.resultId = resultId;
        this.questionId = questionId;
        this.examId = examId;
        this.userId = userId;
        this.optionId = optionId;
        this.selectedOptionId = selectedOptionId;
    }

    public int getId() { 
        return id; 
    }
    public void setId(int id) { 
        this.id = id; 
    }

    public int getResultId() { 
        return resultId; 
    }
    public void setResultId(int resultId) { 
        this.resultId = resultId; 
    }

    public int getUserId() { 
        return userId; 
    }
    public void setUserId(int userId) { 
        this.userId = userId; 
    }   

    public int getOptionId() { 
        return optionId; 
    }
    public void setOptionId(int optionId) { 
        this.optionId = optionId; 
    }

    public int getQuestionId() { 
        return questionId; 
    }
    public void setQuestionId(int questionId) { 
        this.questionId = questionId; 
    }

    public int getExamId() { 
        return examId; 
    }
    public void setExamId(int examId) { 
        this.examId = examId; 
    }

    public int getSelectedOptionId() { 
        return selectedOptionId; 
    }
    public void setSelectedOptionId(int selectedOptionId) { 
        
        this.selectedOptionId = selectedOptionId; 
    }

    @Override
    public String toString() {
        return "Answer [questionId=" + questionId + ", selectedOptionId=" + selectedOptionId + "]";
    }
}
