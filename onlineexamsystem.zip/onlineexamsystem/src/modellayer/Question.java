package modellayer;

public class Question {
    private int id;
    private int examId;
    private String text;
    private int optionId;
    private int marks;
    private int questionOrder;

    public Question(){
    }
    
    public Question(int id, int examId, int optiopnId,String text, int marks, int questionOrder) {
        this.id = id;
        this.examId = examId;
        this.text = text;
        this.marks = marks;
        this.optionId = optionId;
        this.questionOrder = questionOrder;
    }

    public int getId() {
        return id;
    }
    public void setId(int id) { 
        this.id = id;
    }

    public int getExamId() { 
        return examId; 
    }
    public void setExamId(int examId) { 
        this.examId = examId; 
    }

    public int getOptionId() {
        return optionId;
    }
    public void setOptionId(int optionId) {
        this.optionId = optionId;
}

    public String getText() {
        return text; 
    }
    public void setText(String text) { 
        this.text = text; 
    }

    public int getMarks() { 
        return marks; 
    }
    public void setMarks(int marks) { 
        this.marks = marks; 
    }

    public int getQuestionOrder() { 
        return questionOrder; 
    }
    public void setQuestionOrder(int questionOrder) { 
        this.questionOrder = questionOrder; 
    }

    @Override
    public String toString() {
        return "Question [id=" + id + ", text=" + text + "]";
    }
}
