package controller;

import java.util.*;
import modellayer.Result;
import service.serviceimpliments.ResultService;

public class ResultController {
    private final ResultService resultService;
    private static ResultController instance;

     private ResultController() {
        this.resultService = ResultService.getInstance();
    }

    public static synchronized ResultController getInstance() {
        if (instance == null) {
            instance = new ResultController();
        }
        return instance;
    }

    public void evaluateExam(int userId, int examId) {
        try {
            Result result = resultService.evaluateExam(userId, examId);
             result.setPassOrFail(result.getScore(), result.getTotalMarks());
            double percentage = (result.getTotalMarks()>0) ? (result.getScore() * 100.0) / result.getTotalMarks() : 0.0;
            System.out.println(" Exam evaluated!");
            System.out.printf("Score: %.2f%%\n", percentage); 
            System.out.println("Correct Answers: " + result.getCorrectAnswers() + "/" + result.getTotalQuestions());
            System.out.println("Result: " + (result.getPassOrFail() ? "Pass" : "Fail"));
        } catch (Exception e) {
            System.err.println(" Evaluation failed: " + e.getMessage());
        }
    }

    public List<Result> showResult(int userId) {
        try {
            List<Result> results = resultService.getResultsByUserId(userId);
            if (results.isEmpty()) {
                System.out.println("No results found for this user.");
            }
            return results;
        } catch (Exception e) {
            System.err.println("Failed to load results: " + e.getMessage());
            return new ArrayList<>();
        }
    }

    public  List<Result>  showAllResults() {
        try {
            List<Result> results = resultService.getAllResults();
            if (results.isEmpty()) {
                System.out.println(" No results found.");
                return new ArrayList<>();
            }

            System.out.println("\n--- All Exam Results ---");
            return results;

        } catch (Exception e) {
            System.err.println(" Failed to fetch all results: " + e.getMessage());
            return new ArrayList<>();
        }
        finally {
            System.out.println("-----------------------------");
        }
      
    }
}
