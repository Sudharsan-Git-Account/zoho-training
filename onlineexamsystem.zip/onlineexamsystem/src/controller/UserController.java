package controller;

import java.util.*;
import modellayer.User;
import service.serviceimpliments.UserService;

public class UserController {
    private final UserService userService ;
    private static UserController instance;
    
    private UserController() {

        this.userService = UserService.getInstance();
    }

    public static synchronized UserController getInstance() {
        if (instance == null) {
            instance = new UserController();
        }
        return instance;
    }
    
    public void registerUser(String username, String password, String fullName, String role) {
        try {
            User user = new User();
            user.setUsername(username);
            user.setPasswordHash(password);
            user.setFullName(fullName);
            user.setRole(user.getRole().trim().toUpperCase());
            userService.registerUser(user);
            System.out.println(" User registered successfully!");
        } catch (Exception e) {
            System.err.println(" Registration failed: " + e.getMessage());
        }
    }

    public User login(String username, String password) {
        try {
            Optional<User> user = userService.login(username, password);
            if (user.isPresent()) {
                System.out.println(" Login successful! Welcome " + user.get().getFullName());
                return user.get();
            } else {
                System.out.println(" Invalid username or password.");
                return null;
            }
        } catch (Exception e) {
            System.err.println(" Login failed: " + e.getMessage());
            return null;
        }
    }


    public List<User> showAllUsers() {
        try {
            List<User> users = userService.getAllUsers();
            int userNo = 1;
            for(User u : users){
                if(u.getId() != 1){
                    System.out.println(userNo+". "+u.getFullName());
                    userNo++;
                }
                
            }
            return users;
        } catch (Exception e) {
            System.err.println(" Failed to list users: " + e.getMessage());
        }
        return null;
    }

    public void changePassword(User user, String oldPassword, String newPassword) {
        try {
            userService.changePassword(user.getId(), oldPassword, newPassword);
            System.out.println(" Password changed successfully!");
        } catch (Exception e) {
            System.err.println(" Failed to change password: " + e.getMessage());
        }
    }

}
