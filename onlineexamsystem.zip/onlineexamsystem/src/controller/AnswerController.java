package controller;

import service.serviceimpliments.AnswerService;

import java.util.List;

import modellayer.Answer;
public class AnswerController {
    private final AnswerService answerService ;
    private static AnswerController instance;

    private AnswerController() {
        this.answerService = AnswerService.getInstance();
    }

    public static synchronized AnswerController getInstance() {
        if (instance == null) {
            instance = new AnswerController();
        }
        return instance;
    }
    
    public void submitAnswer(int userId, int examId, int questionId, int optionId) {
        try {
            Answer ans = new Answer();
            ans.setUserId(userId);
            ans.setExamId(examId);
            ans.setQuestionId(questionId);
            ans.setOptionId(optionId);
            answerService.saveAnswer(ans);
            System.out.println(" Answer submitted successfully!");
        } catch (Exception e) {
            System.err.println(" Failed to submit answer: " + e.getMessage());
        }
    }
    public void listAnswers(int userId, int examId) {
        try {
            List<Answer> answers = answerService.getAnswersByResultId(userId,examId);
            for (Answer a : answers) {
                System.out.println("Question ID: " + a.getQuestionId() + ", Selected Option ID: " + a.getOptionId());
            }
        } catch (Exception e) {
            System.out.println(" Error fetching answers: " + e.getMessage());
        }
    }
}
