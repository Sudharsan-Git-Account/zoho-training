package controller;

import modellayer.Option;
import service.serviceimpliments.OptionService;

import java.util.*;

public class OptionController {
    private final OptionService optionService;
    private static OptionController instance;

     private OptionController() {
        this.optionService = OptionService.getInstance();
    }

    public static synchronized OptionController getInstance() {
        if (instance == null) {
            instance = new OptionController();
        }
        return instance;
    }

    public Option addOption(int questionId, String text, boolean isCorrect) {
        try {
            Option option = new Option();
            option.setQuestionId(questionId);
            option.setText(text);
            option.setCorrect(isCorrect);
            return optionService.addOption(option);

        } catch (Exception e) {
            System.out.println(" Failed to add option: " + e.getMessage());
        }
        return null;
    }

    public void listOptions(int questionId) {
        try {
            List<Option> options = optionService.getOptionsByQuestion(questionId);
            for (Option o : options) {
                System.out.println(o.getId() + ". " + o.getText() + (o.isCorrect() ? " Correct" : ""));
            }
        } catch (Exception e) {
            System.out.println(" Error fetching options: " + e.getMessage());
        }
    }
}
