package controller;

import modellayer.*;
import dao.daoimplimentations.AnswerDAO;
import dao.daoimplimentations.OptionDAO;
import service.serviceimpliments.ExamService;
import java.util.*;

public class ExamController {
    private final ExamService examService;
    private static ExamController instance;

     private ExamController() {
        this.examService = ExamService.getInstance();
    }

    public static synchronized ExamController getInstance() {
        if (instance == null) {
            instance = new ExamController();
        }
        return instance;
    }
    public void createExam(String title, String description, int duration, int createdBy) {
        try {
            Exam exam = new Exam();
            exam.setTitle(title);
            exam.setDescription(description);
            exam.setDurationMinutes(duration);
            exam.setCreatedBy(createdBy);
            examService.createExam(exam);
            System.out.println(" Exam created successfully!");
        } catch (Exception e) {
            System.err.println(" Failed to create exam: " + e.getMessage());
        }
    }

    public void updateExam(int id, String title, String description, int duration) {
        try {
            Optional<Exam> existing = examService.getExamById(id);
            if (existing.isEmpty()) {
                System.err.println(" Exam not found for update");
                return;
            }
            Exam exam = existing.get();
            exam.setTitle(title);
            exam.setDescription(description);
            exam.setDurationMinutes(duration);
            examService.updateExam(exam);
            System.out.println(" Exam updated successfully!");
        } catch (Exception e) {
            System.err.println(" Failed to update exam: " + e.getMessage());
        }
    }

    public void deleteExam(int id) {
        try {
            boolean deleted = examService.removeExam(id);
            if (deleted) {
                System.out.println(" Exam deleted successfully!");
            } else {
                System.err.println(" Exam not found for deletion");
            }
        } catch (Exception e) {
            System.err.println(" Failed to delete exam: " + e.getMessage());
        }
    }

     public void evaluateAndSaveResult(int userId, int examId) {
        try {
            examService.evaluateAndSaveResult(userId,examId);
            System.out.println(" Exam evaluated and result saved successfully for exam ID: " + examId);
        } catch (Exception e) {
            System.err.println(" Failed to Evaluate Exam: " + e.getMessage());
        }
    }


    public List<Exam> getAllExams() {
            List<Exam> exams;
        try {
            exams = examService.getAllExams();
            for (Exam ex : exams) {
                return exams;
            }
        } catch (Exception e) {
            return null;
        }
        return exams;
    }

    public List<Exam> searchExamByTitle(String keyword) {
        try {
            List<Exam> all = examService.getAllExams();
            List<Exam> result = new ArrayList<>();
            if (keyword == null || keyword.trim().isEmpty()) return all;
            String kw = keyword.toLowerCase();
            for (Exam ex : all) {
                if (ex.getTitle() != null && ex.getTitle().toLowerCase().contains(kw)) result.add(ex);
            }
            return result;
        } catch (Exception e) {
            System.err.println("Error searching exams: " + e.getMessage());
            return new ArrayList<>();
        }
    }

    public List<Question> getQuestionsByExamId(int examId)  {
        try{
            return examService.getQuestionsByExamId(examId);
        }catch(Exception e) {
            e.printStackTrace();
            return new ArrayList<>();
        }
    }

    public List<Option> getOptionsByQuestionId(int questionId){
        try{
            return examService.getOptionsByQuestionId(questionId);
        }catch(Exception e) {
            e.printStackTrace();
            return new ArrayList<>();
        }
    }

    public void saveAnswer(int userId, int examId, int questionId, int selectedOptionId) {
        examService.saveAnswer(userId, examId, questionId, selectedOptionId);
    }


    public void evaluateAndShow(int userId,int resultId, int examId) {
        try {
            Result r = examService.evaluateAndSaveResult(userId,examId);
            System.out.println("Score: " + r.getScore() + "% (" + r.getCorrectAnswers() + "/" + r.getTotalQuestions() + ")");
        } catch (Exception e) {
            System.out.println("Evaluate failed: " + e.getMessage());
        }
    }
    public List<Answer> getAnswersByUserAndExam(int userId, int examId) throws Exception {
    return AnswerDAO.getInstance().findByUserAndExam(userId, examId);
}

public String getOptionTextById(int optionId) {
    try {
        Option opt = OptionDAO.getInstance().findById(optionId);
        return opt != null ? opt.getText() : "(Unknown)";
    } catch (Exception e) {
        return "(Error)";
    }
}

public String getCorrectOptionText(int questionId) {
    try {
        List<Option> opts = OptionDAO.getInstance().findByQuestionId(questionId);
        for (Option o : opts) {
            if (o.isCorrect()) return o.getText();
        }
    } catch (Exception ignored) {}
    return "(Unknown)";
}

public int getCorrectOptionId(int questionId) {
    try {
        List<Option> opts = OptionDAO.getInstance().findByQuestionId(questionId);
        for (Option o : opts) {
            if (o.isCorrect()) return o.getId();
        }
    } catch (Exception ignored) {}
    return -1;
}

}
