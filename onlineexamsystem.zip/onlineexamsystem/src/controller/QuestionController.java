package controller;

import modellayer.Question;
import service.serviceimpliments.QuestionService;

import java.util.*;

public class QuestionController {
    private final QuestionService questionService;
    private static QuestionController instance;

    private QuestionController() {
        this.questionService = QuestionService.getInstance();
    }

    public static synchronized QuestionController getInstance() {
        if (instance == null) {
            instance = new QuestionController();
        }
        return instance;
    }
    public Question addQuestion(int examId, String text, int marks) {
        try {
            Question q = new Question();
            q.setExamId(examId);
            q.setText(text);
            q.setMarks(marks);
            return questionService.addQuestion(q);

        } catch (Exception e) {
            System.out.println(" Failed to add question: " + e.getMessage());
        }
        return null;
    }

    public boolean updateQuestion(Question question) throws Exception {
        return questionService.updateQuestion(question);
    }

    public void listQuestions(int examId) {
        try {
            List<Question> list = questionService.getQuestionsByExam(examId);
            for (Question q : list) {
                System.out.println(q.getId() + ". " + q.getText() + " (" + q.getMarks() + " marks)");
            }
        } catch (Exception e) {
            System.err.println(" Error fetching questions: " + e.getMessage());
        }
    }
}
