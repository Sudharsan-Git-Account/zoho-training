INSERT INTO users (username, password_hash, user_name, role)
VALUES
    ('admin@gmail.com', 'admin123', 'System Administrator', 'ADMIN'),
    ('student@gmail.com', 'student123', 'Student', 'STUDENT'),
    ('sudharsans@gmail.com', 'sudharsan', 'Sudharsan', 'STUDENT');

-- Insert Exams
INSERT INTO exams (title, description, total_marks, duration_minutes, created_by)
VALUES
    ('Java Basics', 'Test your knowledge of core Java concepts.', 3, 30, 1),
    ('OOP Fundamentals', 'Concepts of inheritance, abstraction, and polymorphism.', 3, 30, 1),
    ('Data Structures Basics', 'Stacks, queues, arrays concepts.', 3, 30, 1),
    ('SQL Fundamentals', 'Test your SQL knowledge.', 3, 30, 1);

-- Insert Questions
INSERT INTO questions (exam_id, text, marks, question_order) VALUES
    (1, 'What is the size of int in Java?', 1, 1),
    (1, 'Which keyword is used to inherit a class in Java?', 1, 2),
    (1, 'Which method is the entry point of a Java program?', 1, 3),
    (1, 'Which of these is NOT a Java primitive data type?', 1, 4),
    (1, 'Which method is used to get the length of an array in Java?', 1, 5),
    (1, 'Which operator is used for logical AND in Java?', 1, 6),
    (1, 'What does JVM stand for?', 1, 7),
    (1, 'Which keyword is used to create an object in Java?', 1, 8),

    (2, 'Which concept allows multiple forms of a method in Java?', 1, 1),
    (2, 'Which keyword prevents method overriding?', 1, 2),
    (2, 'Which of the following is not an OOP principle?', 1, 3),
    (2, 'Which OOP principle allows objects to take many forms?', 1, 4),
    (2, 'Which concept bundles data and methods together?', 1, 5),
    (2, 'Which keyword is used to call a parent class constructor?', 1, 6),
    (2, 'Which type of class cannot be instantiated?', 1, 7),
    (2, 'What is method overloading?', 1, 8),

    (3, 'Which data structure uses LIFO?', 1, 1),
    (3, 'Which of these is a linear data structure?', 1, 2),
    (3, 'Which data structure uses FIFO?', 1, 3),
    (3, 'Which data structure uses key–value pairs?', 1, 4),
    (3, 'Which operation removes an element from a queue?', 1, 5),
    (3, 'Which data structure is best suited for recursion?', 1, 6),
    (3, 'Which has the fastest access time?', 1, 7),
    (3, 'Which traversal method is used in binary trees?', 1, 8),

    (4, 'Which command is used to retrieve data from a database?', 1, 1),
    (4, 'Which clause is used to filter records in SQL?', 1, 2),
    (4, 'Which keyword is used to sort query results?', 1, 3),
    (4, 'Which SQL statement is used to remove a table?', 1, 4),
    (4, 'Which function returns the total number of rows?', 1, 5),
    (4, 'Which keyword is used to eliminate duplicate rows?', 1, 6),
    (4, 'What does the LIKE operator do?', 1, 7),
    (4, 'Which operator checks for NULL values?', 1, 8);

-- Insert Options
INSERT INTO options (question_id, text, is_correct)
VALUES
-- exam 1
((SELECT id FROM questions WHERE exam_id=1 AND question_order=1), '2 bytes', FALSE),
((SELECT id FROM questions WHERE exam_id=1 AND question_order=1), '4 bytes', TRUE),
((SELECT id FROM questions WHERE exam_id=1 AND question_order=1), '8 bytes', FALSE),
((SELECT id FROM questions WHERE exam_id=1 AND question_order=1), 'Depends on OS', FALSE),

((SELECT id FROM questions WHERE exam_id=1 AND question_order=2), 'this', FALSE),
((SELECT id FROM questions WHERE exam_id=1 AND question_order=2), 'super', FALSE),
((SELECT id FROM questions WHERE exam_id=1 AND question_order=2), 'extends', TRUE),
((SELECT id FROM questions WHERE exam_id=1 AND question_order=2), 'implements', FALSE),

((SELECT id FROM questions WHERE exam_id=1 AND question_order=3), 'start()', FALSE),
((SELECT id FROM questions WHERE exam_id=1 AND question_order=3), 'run()', FALSE),
((SELECT id FROM questions WHERE exam_id=1 AND question_order=3), 'main()', TRUE),
((SELECT id FROM questions WHERE exam_id=1 AND question_order=3), 'execute()', FALSE),

((SELECT id FROM questions WHERE exam_id=1 AND question_order=4), 'int', FALSE),
((SELECT id FROM questions WHERE exam_id=1 AND question_order=4), 'float', FALSE),
((SELECT id FROM questions WHERE exam_id=1 AND question_order=4), 'String', TRUE),
((SELECT id FROM questions WHERE exam_id=1 AND question_order=4), 'boolean', FALSE),

((SELECT id FROM questions WHERE exam_id=1 AND question_order=5), 'length', TRUE),
((SELECT id FROM questions WHERE exam_id=1 AND question_order=5), 'size()', FALSE),
((SELECT id FROM questions WHERE exam_id=1 AND question_order=5), 'count()', FALSE),
((SELECT id FROM questions WHERE exam_id=1 AND question_order=5), 'length()', FALSE),

((SELECT id FROM questions WHERE exam_id=1 AND question_order=6), '&', FALSE),
((SELECT id FROM questions WHERE exam_id=1 AND question_order=6), '&&', TRUE),
((SELECT id FROM questions WHERE exam_id=1 AND question_order=6), '||', FALSE),
((SELECT id FROM questions WHERE exam_id=1 AND question_order=6), 'and', FALSE),

((SELECT id FROM questions WHERE exam_id=1 AND question_order=7), 'Java Variable Machine', FALSE),
((SELECT id FROM questions WHERE exam_id=1 AND question_order=7), 'Java Virtual Mechanism', FALSE),
((SELECT id FROM questions WHERE exam_id=1 AND question_order=7), 'Java Virtual Machine', TRUE),
((SELECT id FROM questions WHERE exam_id=1 AND question_order=7), 'Java Version Manager', FALSE),

((SELECT id FROM questions WHERE exam_id=1 AND question_order=8), 'create', FALSE),
((SELECT id FROM questions WHERE exam_id=1 AND question_order=8), 'new', TRUE),
((SELECT id FROM questions WHERE exam_id=1 AND question_order=8), 'object', FALSE),
((SELECT id FROM questions WHERE exam_id=1 AND question_order=8), 'init', FALSE),

-- exam 2
((SELECT id FROM questions WHERE exam_id=2 AND question_order=1), 'Encapsulation', FALSE),
((SELECT id FROM questions WHERE exam_id=2 AND question_order=1), 'Polymorphism', TRUE),
((SELECT id FROM questions WHERE exam_id=2 AND question_order=1), 'Inheritance', FALSE),
((SELECT id FROM questions WHERE exam_id=2 AND question_order=1), 'Abstraction', FALSE),

((SELECT id FROM questions WHERE exam_id=2 AND question_order=2), 'final', TRUE),
((SELECT id FROM questions WHERE exam_id=2 AND question_order=2), 'static', FALSE),
((SELECT id FROM questions WHERE exam_id=2 AND question_order=2), 'abstract', FALSE),
((SELECT id FROM questions WHERE exam_id=2 AND question_order=2), 'const', FALSE),

((SELECT id FROM questions WHERE exam_id=2 AND question_order=3), 'Inheritance', FALSE),
((SELECT id FROM questions WHERE exam_id=2 AND question_order=3), 'Encapsulation', FALSE),
((SELECT id FROM questions WHERE exam_id=2 AND question_order=3), 'Polymorphism', FALSE),
((SELECT id FROM questions WHERE exam_id=2 AND question_order=3), 'Recursion', TRUE),

((SELECT id FROM questions WHERE exam_id=2 AND question_order=4), 'Encapsulation', FALSE),
((SELECT id FROM questions WHERE exam_id=2 AND question_order=4), 'Inheritance', FALSE),
((SELECT id FROM questions WHERE exam_id=2 AND question_order=4), 'Polymorphism', TRUE),
((SELECT id FROM questions WHERE exam_id=2 AND question_order=4), 'Abstraction', FALSE),

((SELECT id FROM questions WHERE exam_id=2 AND question_order=5), 'Polymorphism', FALSE),
((SELECT id FROM questions WHERE exam_id=2 AND question_order=5), 'Abstraction', FALSE),
((SELECT id FROM questions WHERE exam_id=2 AND question_order=5), 'Encapsulation', TRUE),
((SELECT id FROM questions WHERE exam_id=2 AND question_order=5), 'Inheritance', FALSE),

((SELECT id FROM questions WHERE exam_id=2 AND question_order=6), 'super()', TRUE),
((SELECT id FROM questions WHERE exam_id=2 AND question_order=6), 'parent()', FALSE),
((SELECT id FROM questions WHERE exam_id=2 AND question_order=6), 'base()', FALSE),
((SELECT id FROM questions WHERE exam_id=2 AND question_order=6), 'this()', FALSE),

((SELECT id FROM questions WHERE exam_id=2 AND question_order=7), 'final', FALSE),
((SELECT id FROM questions WHERE exam_id=2 AND question_order=7), 'abstract', TRUE),
((SELECT id FROM questions WHERE exam_id=2 AND question_order=7), 'static', FALSE),
((SELECT id FROM questions WHERE exam_id=2 AND question_order=7), 'private', FALSE),

((SELECT id FROM questions WHERE exam_id=2 AND question_order=8), 'Same name, different parameters', TRUE),
((SELECT id FROM questions WHERE exam_id=2 AND question_order=8), 'Same name in parent-child classes', FALSE),
((SELECT id FROM questions WHERE exam_id=2 AND question_order=8), 'Same return type only', FALSE),
((SELECT id FROM questions WHERE exam_id=2 AND question_order=8), 'Multiple classes sharing method', FALSE),

-- exam 3
((SELECT id FROM questions WHERE exam_id=3 AND question_order=1), 'Queue', FALSE),
((SELECT id FROM questions WHERE exam_id=3 AND question_order=1), 'Stack', TRUE),
((SELECT id FROM questions WHERE exam_id=3 AND question_order=1), 'Tree', FALSE),
((SELECT id FROM questions WHERE exam_id=3 AND question_order=1), 'Array', FALSE),

((SELECT id FROM questions WHERE exam_id=3 AND question_order=2), 'Queue', TRUE),
((SELECT id FROM questions WHERE exam_id=3 AND question_order=2), 'Graph', FALSE),
((SELECT id FROM questions WHERE exam_id=3 AND question_order=2), 'Binary Tree', FALSE),
((SELECT id FROM questions WHERE exam_id=3 AND question_order=2), 'Heap', FALSE),

((SELECT id FROM questions WHERE exam_id=3 AND question_order=3), 'Queue', TRUE),
((SELECT id FROM questions WHERE exam_id=3 AND question_order=3), 'Stack', FALSE),
((SELECT id FROM questions WHERE exam_id=3 AND question_order=3), 'Array', FALSE),
((SELECT id FROM questions WHERE exam_id=3 AND question_order=3), 'Tree', FALSE),

((SELECT id FROM questions WHERE exam_id=3 AND question_order=4), 'Array', FALSE),
((SELECT id FROM questions WHERE exam_id=3 AND question_order=4), 'Stack', FALSE),
((SELECT id FROM questions WHERE exam_id=3 AND question_order=4), 'Queue', FALSE),
((SELECT id FROM questions WHERE exam_id=3 AND question_order=4), 'Map', TRUE),

((SELECT id FROM questions WHERE exam_id=3 AND question_order=5), 'push', FALSE),
((SELECT id FROM questions WHERE exam_id=3 AND question_order=5), 'pop', FALSE),
((SELECT id FROM questions WHERE exam_id=3 AND question_order=5), 'enqueue', FALSE),
((SELECT id FROM questions WHERE exam_id=3 AND question_order=5), 'dequeue', TRUE),

((SELECT id FROM questions WHERE exam_id=3 AND question_order=6), 'Array', FALSE),
((SELECT id FROM questions WHERE exam_id=3 AND question_order=6), 'Queue', FALSE),
((SELECT id FROM questions WHERE exam_id=3 AND question_order=6), 'Stack', TRUE),
((SELECT id FROM questions WHERE exam_id=3 AND question_order=6), 'Graph', FALSE),

((SELECT id FROM questions WHERE exam_id=3 AND question_order=7), 'Array', TRUE),
((SELECT id FROM questions WHERE exam_id=3 AND question_order=7), 'Linked List', FALSE),
((SELECT id FROM questions WHERE exam_id=3 AND question_order=7), 'Graph', FALSE),
((SELECT id FROM questions WHERE exam_id=3 AND question_order=7), 'Queue', FALSE),

((SELECT id FROM questions WHERE exam_id=3 AND question_order=8), 'Inorder', TRUE),
((SELECT id FROM questions WHERE exam_id=3 AND question_order=8), 'Random', FALSE),
((SELECT id FROM questions WHERE exam_id=3 AND question_order=8), 'Reverse', FALSE),
((SELECT id FROM questions WHERE exam_id=3 AND question_order=8), 'BFS only', FALSE),

-- exam 4
((SELECT id FROM questions WHERE exam_id=4 AND question_order=1), 'SELECT', TRUE),
((SELECT id FROM questions WHERE exam_id=4 AND question_order=1), 'INSERT', FALSE),
((SELECT id FROM questions WHERE exam_id=4 AND question_order=1), 'UPDATE', FALSE),
((SELECT id FROM questions WHERE exam_id=4 AND question_order=1), 'DELETE', FALSE),

((SELECT id FROM questions WHERE exam_id=4 AND question_order=2), 'WHERE', TRUE),
((SELECT id FROM questions WHERE exam_id=4 AND question_order=2), 'ORDER BY', FALSE),
((SELECT id FROM questions WHERE exam_id=4 AND question_order=2), 'FROM', FALSE),
((SELECT id FROM questions WHERE exam_id=4 AND question_order=2), 'GROUP BY', FALSE),

((SELECT id FROM questions WHERE exam_id=4 AND question_order=3), 'ORDER BY', TRUE),
((SELECT id FROM questions WHERE exam_id=4 AND question_order=3), 'GROUP BY', FALSE),
((SELECT id FROM questions WHERE exam_id=4 AND question_order=3), 'WHERE', FALSE),
((SELECT id FROM questions WHERE exam_id=4 AND question_order=3), 'HAVING', FALSE),

((SELECT id FROM questions WHERE exam_id=4 AND question_order=4), 'DELETE', FALSE),
((SELECT id FROM questions WHERE exam_id=4 AND question_order=4), 'REMOVE', FALSE),
((SELECT id FROM questions WHERE exam_id=4 AND question_order=4), 'DROP', TRUE),
((SELECT id FROM questions WHERE exam_id=4 AND question_order=4), 'TRUNCATE', FALSE),

((SELECT id FROM questions WHERE exam_id=4 AND question_order=5), 'SUM()', FALSE),
((SELECT id FROM questions WHERE exam_id=4 AND question_order=5), 'COUNT()', TRUE),
((SELECT id FROM questions WHERE exam_id=4 AND question_order=5), 'TOTAL()', FALSE),
((SELECT id FROM questions WHERE exam_id=4 AND question_order=5), 'SIZE()', FALSE),

((SELECT id FROM questions WHERE exam_id=4 AND question_order=6), 'UNIQUE', FALSE),
((SELECT id FROM questions WHERE exam_id=4 AND question_order=6), 'DISTINCT', TRUE),
((SELECT id FROM questions WHERE exam_id=4 AND question_order=6), 'REMOVE DUPLICATE', FALSE),
((SELECT id FROM questions WHERE exam_id=4 AND question_order=6), 'CLEAN', FALSE),

((SELECT id FROM questions WHERE exam_id=4 AND question_order=7), 'Sorts results', FALSE),
((SELECT id FROM questions WHERE exam_id=4 AND question_order=7), 'Filters using patterns', TRUE),
((SELECT id FROM questions WHERE exam_id=4 AND question_order=7), 'Groups rows', FALSE),
((SELECT id FROM questions WHERE exam_id=4 AND question_order=7), 'Deletes rows', FALSE),

((SELECT id FROM questions WHERE exam_id=4 AND question_order=8), '= NULL', FALSE),
((SELECT id FROM questions WHERE exam_id=4 AND question_order=8), '== NULL', FALSE),
((SELECT id FROM questions WHERE exam_id=4 AND question_order=8), 'IS NULL', TRUE),
((SELECT id FROM questions WHERE exam_id=4 AND question_order=8), 'EQUAL NULL', FALSE);

-- Insert Results
INSERT INTO results (exam_id, user_id, score, total_marks, correct_answers, total_questions)
VALUES
    (1, 2, 7, 8, 7, 8),
    (1, 3, 5, 8, 5, 8),
    (2, 2, 8, 8, 8, 8),
    (2, 3, 3, 8, 3, 8),
    (3, 2, 7, 8, 7, 8),
    (3, 3, 4, 8, 4, 8),
    (4, 2, 8, 8, 8, 8),
    (4, 3, 2, 8, 2, 8);