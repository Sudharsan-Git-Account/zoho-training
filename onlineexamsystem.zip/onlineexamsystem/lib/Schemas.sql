            DROP TABLE IF EXISTS answers CASCADE;
            DROP TABLE IF EXISTS results CASCADE;
            DROP TABLE IF EXISTS options CASCADE;
            DROP TABLE IF EXISTS questions CASCADE;
            DROP TABLE IF EXISTS exams CASCADE;
            DROP TABLE IF EXISTS users CASCADE;

            DROP TYPE IF EXISTS user_role CASCADE;
            CREATE TYPE user_role AS ENUM ('ADMIN', 'STUDENT');

            CREATE TABLE users (
                id INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
                username VARCHAR(50) UNIQUE NOT NULL,
                password_hash VARCHAR(255) NOT NULL,
                user_name VARCHAR(100),
                role user_role NOT NULL DEFAULT 'STUDENT',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );

            CREATE TABLE exams (
                id INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
                title VARCHAR(200) NOT NULL,
                description TEXT,
                total_marks INT DEFAULT 0,
                duration_minutes INT DEFAULT 0,
                created_by INT REFERENCES users(id) ON DELETE SET NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );

            CREATE TABLE questions (
                id INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
                exam_id INT REFERENCES exams(id) ON DELETE CASCADE,
                text TEXT NOT NULL,
                marks INT DEFAULT 1,
                question_order INT DEFAULT 0
            );

            CREATE TABLE options (
                id INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
                question_id INT REFERENCES questions(id) ON DELETE CASCADE,
                text TEXT NOT NULL,
                is_correct BOOLEAN DEFAULT FALSE
            );

            CREATE TABLE results (
                id SERIAL PRIMARY KEY,
                exam_id INT REFERENCES exams(id),
                user_id INT REFERENCES users(id),
                score INT,
                total_marks INT,
                correct_answers INT DEFAULT 0,
                total_questions INT DEFAULT 0,
                taken_at TIMESTAMP DEFAULT NOW()
            );
                
            CREATE TABLE answers (
                 id SERIAL PRIMARY KEY,
                 user_id INT NOT NULL REFERENCES users(id),
                 exam_id INT NOT NULL REFERENCES exams(id),
                 question_id INT NOT NULL REFERENCES questions(id),
                 selected_option_id INT NOT NULL REFERENCES options(id)
            );
            
            DELETE FROM results WHERE id IN (
                  SELECT id FROM results
                  WHERE (user_id, exam_id) IN (
                    SELECT user_id, exam_id FROM results GROUP BY user_id, exam_id HAVING COUNT(*) > 1
                  )
                  AND id NOT IN (
                    SELECT MIN(id) FROM results GROUP BY user_id, exam_id HAVING COUNT(*) > 1
                  )
            );
