package src;

import src.view.MainView;

public class App {

    public static void main(String[] args) {
        MainView mainView = new MainView();
        mainView.displayMainMenu();

    }
}